import os.path
import os.path as path
from os import makedirs as makedirs
import json
from time import time
# basic url support
import urllib.request
import urllib.parse
import urllib.error

# packed update support
import gzip
import zipfile
from io import BytesIO

# interactive commandline
import icmdline

from sources import freemusicarchive

__version__ = 2
__author__ = None


RETVAL_FAIL = 1
RETVAL_OK = 0


class Config:
    WWW_UPDATE_MARKER = {'update': True}
    WWW_UPDATE_FLAG_URL = 'https://raw.githubusercontent.com/drdoinstuff/test/main/test.json'
    CONST_REL_CONFIG_PATH = './config/main.json'
    CONST_CONFIG_DEFAULT = {'name': 'test',
                            'version': 0,
                            'update_flag': WWW_UPDATE_FLAG_URL,
                            'last checked': time()}


class Msg:
    MSG_ERROR_FILE_NOT_EXIST = "ERROR: File does not exist: {0}"
    MSG_ERROR_FILE_NOT_OPEN = "ERROR: Could not open file: {0}"
    MSG_ERROR_FILE_NOT_OVERWRITTEN = "ERROR: Did not overwrite file: {0}"
    MSG_INFO_CREATED_DIR = "INFO: Created folder {0} in parent {1}"

def killspawned():
    """killspawned
    :argument: None
    Kill all spawned processes and threads"""
    pass


def removetempfiles():
    """removetempfiles
    :argument: None
    Remove any temporary files written to disk.
    Includes; all project files written out to disk.
    """
    pass


def createdirectorys():
    """createdirectorys
    :argument: a list of relative paths
    example: ["./temp/", "./video/", "./music/"]
    """
    pass


def loadconfig(file_path: str) -> dict:
    """loadconfig
    :argument: path to config
    Opens a file pointer to the given path
    reads the json config file and returns
    a constructed "configuration" object.
    """
    if path.exists(file_path):  # try to load a json file
        with open(file_path, 'r') as file:
            obj = json.load(file)
        return obj
    else:
        print(Msg.MSG_ERROR_FILE_NOT_EXIST.format(file_path))
        return {}


def writeconfig(file_path: str, _config: dict) -> int:
    """writeconfig
    :file_path: "path to config file"
    :config: "dict to write as json file"

    Create the path to file and write out json dict if given.
    """
    if path.exists(file_path) and path.isfile(file_path):  # avoid clobbering existing config with new file
        print(Msg.MSG_ERROR_FILE_NOT_OVERWRITTEN.format(file_path))
        return RETVAL_FAIL
    else:   # create the parent directories
        makedirs(file_path[:file_path.rfind(path.sep)+1], mode=0o777, exist_ok=True)
        fp = open(file_path, "w")
        fp.writelines(json.dumps(_config, sort_keys=True, indent=4))
        fp.close()
        return RETVAL_OK

def getupdate(url: str):
    """
    getupdate(http://update.site/text.json)

    Try to connect to the url, download the json file, write to disk and reload the config.
    :param url:
    :return:
    """
    # update from raw public file on github
    # check flag file
    update_source = None
    update_key = None
    with urllib.request.urlopen(url) as r:
        a = r.read().decode().strip()
        print(a)
        config = json.loads(a) # must be raw file
    print(config['version'])
    if config['version'] != __version__:
        update_source = config['url']
        key = config['key']
        #follow flag url to zip distribution
        with urllib.request.urlopen(update_source) as ur:
            buffer = BytesIO(ur.read())
            with zipfile.ZipFile(buffer.getbuffer(), 'r', key) as zip:
                extracted = zip.read()
    print(extracted)
    return extracted

if __name__ == "__main__":
    class Main:
        def __init__(self):
            pass

        def setup(self):
            # create paths and config files
            if not path.exists(Config.CONST_REL_CONFIG_PATH):  # write a config file if one doesnt already exist
                if writeconfig(Config.CONST_REL_CONFIG_PATH, Config.CONST_CONFIG_DEFAULT):
                    exit()  # failed
            config = loadconfig(Config.CONST_REL_CONFIG_PATH)  # load config
            a = getupdate(Config.CONST_CONFIG_DEFAULT['update_flag'])
            print(a)
            #t = json.loads(a)
            #print(t)
            #print((time()-config['last checked'])/10)


        def cleanup(self):
            pass


        def run(self):
            """main
            :argument: None
            Main Program thread.
            maintains state and coordinates other p
            arts of the script and external programs
            """

            pass

    instance = Main()
    instance.setup()
    instance.run()
    instance.cleanup()
    exit()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
