import os.path
import os.path as path
import shutil
import sys
from os import makedirs as makedirs
import json
from time import time
from pathlib import Path
# basic url support
import urllib.request
import urllib.parse
import urllib.error

# packed update support
import gzip
import zipfile
from io import BytesIO

# interactive commandline
import icmdline

from sources import freemusicarchive

__version__ = 2
__author__ = None


RETVAL_FAIL = 1
RETVAL_OK = 0



class Debug:
    OFFLINE = False
    ON = True
    OFF = not ON



class Config:
    CONST_ENCODING = 'UTF-8'
    WWW_UPDATE_MARKER = {'update': True}
    WWW_UPDATE_FLAG_URL = 'https://raw.githubusercontent.com/drdoinstuff/test/main/test.json'
    CONST_REL_CONFIG_PATH = Path('./config/main.json')
    CONST_CONFIG_DEFAULT = {'name': 'test',
                            'version': 0,
                            'update_flag': WWW_UPDATE_FLAG_URL,
                            'last checked': time()}

class Redist:
    MAKE_REDIST = True
    PATH = 'release.zip'
    FILELIST = ['main.py', Config.CONST_REL_CONFIG_PATH]
    PASSWORD = '123'

class Msg:
    MSG_ERROR_FILE_NOT_EXIST = 'ERROR: File does not exist: {0}'
    MSG_ERROR_FILE_NOT_OPEN = 'ERROR: Could not open file: {0}'
    MSG_ERROR_FILE_NOT_OVERWRITTEN = 'ERROR: Did not overwrite file: {0}'
    MSG_INFO_CREATED_DIR = 'INFO: Created folder {0} in parent {1}'
    MSG_WROTE_REDISTRIBUTABLE_ZIP = 'INFO: Created zip to redistribute'

def killspawned():
    """killspawned
    :argument: None
    Kill all spawned processes and threads"""
    pass


def removetempfiles():
    """removetempfiles
    :argument: None
    Remove any temporary files written to disk.
    Includes; all project files written out to disk.
    """
    pass


def createdirectorys():
    """createdirectorys
    :argument: a list of relative paths
    example: ["./temp/", "./video/", "./music/"]
    """
    pass


def loadconfig(file_path: str) -> dict:
    """loadconfig
    :argument: path to config
    Opens a file pointer to the given path
    reads the json config file and returns
    a constructed "configuration" object.
    """
    if path.exists(file_path):  # try to load a json file
        with open(file_path, 'r') as file:
            obj = json.load(file)
        return obj
    else:
        print(Msg.MSG_ERROR_FILE_NOT_EXIST.format(file_path))
        return {}


def writeconfig(file_path: str, _config: dict) -> int:
    """writeconfig
    :file_path: "path to config file"
    :config: "dict to write as json file"

    Create the path to file and write out json dict if given.
    """
    if path.exists(file_path) and path.isfile(file_path):  # avoid clobbering existing config with new file
        print(Msg.MSG_ERROR_FILE_NOT_OVERWRITTEN.format(file_path))
        return RETVAL_FAIL
    else:   # create the parent directories
        makedirs(file_path[:file_path.rfind(path.sep)+1], mode=0o777, exist_ok=True)
        fp = open(file_path, "w")
        fp.writelines(json.dumps(_config, sort_keys=True, indent=4))
        fp.close()
        return RETVAL_OK

def getupdate(url: str):
    """
    getupdate(http://update.site/text.json)

    Try to connect to the url, download the json file, write to disk and reload the config.
    :param url:
    :return:
    """
    # update from raw public file on github
    # check flag file and set test config
    if Debug.OFFLINE:
        url = 'test.zip'
        key = '123'
        config = {'version': 1,
                  'url': 'test.zip',
                  'key': '123'}
    else:
        with urllib.request.urlopen(url) as r:
            config = json.loads(r.read().decode().strip())

    if config['version'] != __version__:
        url = config['url']
        key = config['key']
        print(key, url)

        if Debug.OFFLINE:
            with zipfile.ZipFile(config['url'], 'r') as zfile:
                zfile.setpassword(Config.CONST_ENCODING)
                expanded = zfile.read('main.py')
                extracted = expanded.decode().strip()
                print(extracted)
        else:
            # follow flag url to zip distribution
            with urllib.request.urlopen(url) as ur:
                buffer = BytesIO(ur.read())
                with zipfile.ZipFile(buffer, 'r') as zstream:
                    print(type(key), key)
                    zstream.setpassword(bytes(str(key), Config.CONST_ENCODING) )
                    if Debug.ON:
                        #just list files
                        for i in zstream.filelist:
                            print(i.filename)
                        #zstream.filelist[0].filename
                        expanded = zstream.read('main.py')
                        extracted = expanded.decode().strip()
                        #print(extracted)
                    if Debug.OFF:
                        os.mkdir('temp')
                        # launch new process
                        # extract all
                        zstream.extractall('temp')
                        shutil.copytree('temp', '.')
                        shutil.rmtree('temp')
                        os.execl(sys.executable, 'python', __file__, *sys.argv[1:])
                        #

    #                    ur.read(), 'r', key) as zip:
    #                extracted = zip.read()
    return extracted

def writeredistributable(path :str):
    with zipfile.ZipFile(path, 'w') as zfile:
        zfile.setpassword(bytes(Redist.PASSWORD, Config.CONST_ENCODING))
        for f in Redist.FILELIST:
            zfile.write(f)
    print(Msg.MSG_WROTE_REDISTRIBUTABLE_ZIP)
    return 0

if __name__ == "__main__":
    class Main:
        def __init__(self):
            pass

        def setup(self):
            # create paths and config files
            if not path.exists(Config.CONST_REL_CONFIG_PATH):  # write a config file if one doesnt already exist
                if writeconfig(Config.CONST_REL_CONFIG_PATH, Config.CONST_CONFIG_DEFAULT):
                    exit()  # failed
            if Redist.MAKE_REDIST:
                writeredistributable(Redist.PATH)
                exit()
            config = loadconfig(Config.CONST_REL_CONFIG_PATH)  # load config
            #print or overwrite downloaded files
            getupdate(Config.CONST_CONFIG_DEFAULT['update_flag'])

            #t = json.loads(a)
            #print(t)
            #print((time()-config['last checked'])/10)


        def cleanup(self):
            pass


        def run(self):
            """main
            :argument: None
            Main Program thread.
            maintains state and coordinates other p
            arts of the script and external programs
            """

            pass
    instance = Main()
    instance.setup()
    instance.run()
    instance.cleanup()
    exit()